# Judgment Layer for AI-Assisted Engineering

> Beyond the Code — using GitHub Copilot, Devin, and Claude Code as **Judge**, **Advocate**, and **Mediator**.

This repository is the companion code drop for the white paper *"Beyond the Code: LLM Copilot as Judge, Advocate & Mediator"*.

It gives your team **two practical approaches** for installing a judgment layer alongside your AI generation tools.

---

## 📁 Repository Layout

```
judgment-layer/
├── README.md                       ← you are here
├── .env.example                    ← copy → .env, fill in your API keys
├── .gitignore
│
├── .vscode/                        ← Approach A · VS Code right-click commands
│   ├── README.md                   ← setup guide for Approach A
│   ├── tasks.json                  ← right-click task definitions
│   ├── judge_client.py             ← shared provider abstraction
│   ├── team_standards.md           ← your team's versioned rubric (EDIT ME)
│   ├── judge_pr.py                 ← ⚖  Judge: Review this file
│   ├── judge_security.py           ← 🔒  Judge: Security audit
│   ├── advocate_adr.py             ← 📐  Advocate: Generate ADR
│   ├── advocate_devil.py           ← 👿  Advocate: Devil's Advocate
│   ├── mediate_design.py           ← 🤝  Mediate: Design conflict
│   └── mediate_deps.py             ← 📦  Mediate: Resolve dep conflicts
│
├── prompts/                        ← Approach B · Markdown templates
│   ├── README.md                   ← how to use the templates
│   ├── PROMPTS.md                  ← combined index for your team
│   ├── judge-review.md             ← copy & paste into any LLM
│   ├── advocate-adr.md
│   ├── advocate-devil.md
│   └── mediate-design.md
│
├── .github/
│   └── workflows/
│       └── judge-pr.yml            ← optional CI gate (Approach A in CI)
│
└── scorecard/
    ├── README.md
    └── scorecard-template.md       ← 4-week measurement template
```

---

## 🚀 Quick Start

### Approach A — VS Code (5 minute setup)

```bash
# 1. Clone or copy this directory into your repo
cp -r .vscode/ your-repo/

# 2. Install dependencies
pip install anthropic openai

# 3. Configure your provider
cp .env.example .env
# Edit .env — set JUDGE_PROVIDER and the matching API key

# 4. Customise your rubric
# Open .vscode/team_standards.md and edit it for your team's standards

# 5. Run from VS Code
# - Open any code file
# - Cmd/Ctrl + Shift + P → "Tasks: Run Task" → pick a Judge/Advocate/Mediator task
```

### Approach B — Markdown Templates (zero setup)

```bash
# 1. Drop the prompts/ folder into your repo
cp -r prompts/ your-repo/

# 2. Engineers open prompts/PROMPTS.md, copy a template, paste into Claude Code, Devin, or any LLM chat
```

---

## ⚙️  Provider Support

The `judge_client.py` abstraction supports three providers via the `JUDGE_PROVIDER` environment variable:

| Provider | `JUDGE_PROVIDER` | Required env vars |
|---|---|---|
| Anthropic Claude | `anthropic` | `ANTHROPIC_API_KEY` |
| OpenAI | `openai` | `OPENAI_API_KEY` |
| GitHub Copilot endpoint | `copilot` | `OPENAI_API_KEY`, `OPENAI_BASE_URL` |

Switch providers across the entire workflow by changing one variable.

---

## 📊  Measuring Success

After 4 weeks of use, fill in `scorecard/scorecard-template.md` and present the result. The white paper explains how to interpret the score (48-60 = high impact; <24 = re-evaluate).

---

## 🔒  Critical Reminder

> **Trust the copilot — but never outsource your thinking to it.**
>
> Every line of code an engineer accepts becomes their code. The judge / advocate / mediator roles do not transfer accountability — they make accelerated output safe enough to ship. Read every line. Predict the output before you accept it. Track your overrides — they are the calibration signal that keeps your rubric honest.

---

## 📄  License

This judgment layer scaffolding is provided under the MIT License — copy, modify, and ship freely.
