# PROMPTS.md  —  Judgment Layer Templates

> Copy any template below, fill in the `[PLACEHOLDER]` sections, paste into Claude Code, Devin, GitHub Copilot Chat, or any LLM.

---

## ⚖  Judge: Code Review

> **Use when:** you want a structured review of any file, PR diff, or code snippet.

```markdown
# Judge: Code Review

You are a senior code reviewer acting as an impartial judge.
Evaluate the code below against the rubric and return a structured verdict.

## Rubric
- No function exceeds 40 lines
- Every public method has a docstring
- No hardcoded credentials or secrets
- New logic has at least one unit test
- No direct SQL string concatenation
[ADD YOUR OWN TEAM STANDARDS HERE]

## Code to Review
```
[PASTE YOUR CODE OR GIT DIFF HERE]
```

## Output Format
**VERDICT:** APPROVE | REQUEST_CHANGES | BLOCK
**Score:** [0-100]/100
**Summary:** [one sentence]

**Checks:**
| Check | Status | Severity | Comment |
|---|---|---|---|

**Must fix before merge:**
- [only populate if BLOCK or REQUEST_CHANGES]
```

---

## 📐  Advocate: Generate ADR

> **Use when:** you're writing an Architecture Decision Record and want a complete first draft with anticipated objections.

```markdown
# Advocate: Generate Architecture Decision Record

You are a principal software architect. Write a complete ADR for the
proposal below. Include anticipated review objections with pre-prepared
responses — this document will be used in the design review meeting.

## Codebase Context
[PASTE YOUR README OR ARCHITECTURE SUMMARY HERE]

## Proposal
[DESCRIBE YOUR DESIGN IDEA IN 2-5 SENTENCES]

## Output Format — write the ADR as markdown:
# [Title]
**Status:** Proposed   ·   **Date:** [today]
## Context
## Decision
## Rationale
## Alternatives Considered
## Trade-offs
## Consequences
## Anticipated Objections
| Objection | Response |
|---|---|
```

---

## 👿  Advocate: Devil's Advocate

> **Use when:** you're about to commit to a design — stress-test it before handing off to Devin or Claude Code.

```markdown
# Advocate: Devil's Advocate Review

You are a rigorous, constructive senior engineer. Argue AGAINST
the proposal below. Find every legitimate weakness, risk, and
hidden assumption. Be rigorous, not contrarian.

## Proposal
[PASTE YOUR DESIGN PROPOSAL OR REFACTOR PLAN HERE]

## Output Format
**Risk Score:** [0-100]/100
**Verdict:** PROCEED | REVISE | RECONSIDER

**Critical Flaws:**
- [flaw] → [impact if not addressed]

**Hidden Assumptions:**
- [assumption taken for granted]

**Failure Scenarios:**
| Scenario | Likelihood (low/med/high) |
|---|---|

**Minimum changes to PROCEED:**
- [only if verdict is REVISE or RECONSIDER]
```

---

## 🤝  Mediator: Design Conflict

> **Use when:** two engineers disagree and the team is stuck.

```markdown
# Mediator: Design Conflict Resolution

You are a neutral senior architect mediating a design disagreement.
Your goal is NOT to pick a winner — find the synthesis that
preserves the strongest elements of both positions.

## Codebase Context
[PASTE BRIEF SYSTEM DESCRIPTION — stack, scale, constraints]

## Engineer A Position
[PASTE POSITION A HERE]

## Engineer B Position
[PASTE POSITION B HERE]

## Output Format
**Common Ground:**
- [what both sides actually agree on]

**Real Disagreement:** [the actual crux in one sentence]

**Synthesis:** [the recommended unified path]

**Implementation Steps:**
1. ...

**Suggested Experiment:** [smallest test to validate the synthesis]
**Still needs a human decision on:** [what the LLM cannot decide]
```

---

## 🔁  Connecting to Devin / Claude Code

After running any template:

- **Judge** flags issues → paste output back into Claude Code: *"Fix these issues: [paste]"*
- **ADR** generated → paste into Devin task brief: *"Implement the architecture in this ADR: [paste]"*
- **Mediator** synthesis → paste implementation steps into Claude Code session
