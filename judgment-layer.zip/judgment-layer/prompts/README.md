# Approach B · Markdown Prompt Templates

Zero setup. Copy a template, fill in the `[PLACEHOLDER]` sections, paste into Claude Code, Devin, GitHub Copilot Chat, or any LLM interface.

---

## 📋  Templates

| File | Use when... |
|---|---|
| `judge-review.md` | You want a structured review of any file, PR diff, or code snippet |
| `advocate-adr.md` | You're writing an ADR and want a complete first draft with anticipated objections |
| `advocate-devil.md` | You're about to commit to a design decision — stress-test it first |
| `mediate-design.md` | Two engineers disagree and the team is stuck |

---

## 🚀  How To Use

1. Open the relevant template (Judge / Advocate / Mediator).
2. Copy it. Replace every `[PLACEHOLDER]` section with your actual code, proposal, or context.
3. Paste into any LLM interface and send.

That's it. No keys. No setup. No tooling.

---

## 🎯  Sharing With Your Team

Two options for distributing these to your team:

**Option 1: Repo-level**
Drop this `prompts/` folder into the root of your team's repo. Engineers reference it via `prompts/judge-review.md`.

**Option 2: Combined index**
Use `PROMPTS.md` (in this folder) — it concatenates all four templates into a single page that engineers can bookmark, share via Slack, or paste into a Notion doc.

---

## 🔁  Connecting to Devin and Claude Code

After running a template:

- **Judge** finds an issue → paste the LLM's output back into Claude Code: `"Fix these issues: [paste]"`.
- **ADR** is generated → paste it into a Devin task brief: `"Implement the architecture in this ADR: [paste]"`.
- **Mediator** finds a synthesis → paste the synthesis steps into a Claude Code session.

The templates output structured markdown specifically so this paste-back loop is clean.
