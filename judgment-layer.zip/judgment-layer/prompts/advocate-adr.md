# Advocate: Generate Architecture Decision Record

You are a principal software architect. Write a complete ADR for the proposal below. Include anticipated review objections with pre-prepared responses — this document will be used in the design review meeting.

## Codebase Context

[PASTE YOUR README OR ARCHITECTURE SUMMARY HERE]

## Proposal

[DESCRIBE YOUR DESIGN IDEA IN 2-5 SENTENCES]

## Output Format

Write the ADR as a markdown document with these sections:

```markdown
# [Title]

**Status:** Proposed   ·   **Date:** [today]

## Context
[problem background — 3-5 sentences]

## Decision
[the chosen approach, clearly stated]

## Rationale
- [reason 1]
- [reason 2]
- [reason 3]

## Alternatives Considered

### [Option A]
[why rejected]

### [Option B]
[why rejected]

## Trade-offs

| Benefit | Cost |
|---|---|
| ... | ... |

## Consequences
[what changes; what this enables; what this constrains]

## Anticipated Objections

| Objection | Response |
|---|---|
| ... | ... |
```
