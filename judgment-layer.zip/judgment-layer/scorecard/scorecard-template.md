# Judgment Layer Scorecard

> **Team:** _________________
> **Period:** ____ to ____
> **Filled by:** _________________

---

## The Measure Table

| Dimension | Metric | Baseline | Target | Actual (4 wk) | Score 1-5 |
|---|---|---|---|---|---|
| ⚖  Judge | Critical issues caught pre-merge | ___ | ≥ 5 | ___ | ___ |
| ⚖  Judge | PRs auto-evaluated by Judge | 0 | ≥ 50 | ___ | ___ |
| ⚖  Judge | Hours saved on code review | 0 | ≥ 8 | ___ | ___ |
| ⚖  Judge | Override rate (calibration health) | n/a | 10-25% | ___% | ___ |
| 📐  Advocate | ADRs generated | ___ | ≥ 3 | ___ | ___ |
| 📐  Advocate | Design proposals revised after Devil's Advocate | ___ | ≥ 2 | ___ | ___ |
| 📐  Advocate | Hours saved on design-review prep | 0 | ≥ 4 | ___ | ___ |
| 🤝  Mediator | Design conflicts resolved | ___ | ≥ 2 | ___ | ___ |
| 🤝  Mediator | Hours of team stalemate eliminated | 0 | ≥ 6 | ___ | ___ |
| 🤝  Mediator | Agent unblocks (Devin / Claude Code) | 0 | ≥ 4 | ___ | ___ |
| Adoption | % of team using ≥ 1 role weekly | 0% | ≥ 70% | ___% | ___ |
| Adoption | Engineers contributing to team_standards.md | 0 | ≥ 3 | ___ | ___ |
| | | | | **TOTAL** | **___ / 60** |

---

## Scoring Rubric

| Score | Meaning |
|---|---|
| 5 | Significantly exceeded target |
| 4 | Met target |
| 3 | Approached target (≥70%) |
| 2 | Partial progress (≥30%) |
| 1 | No measurable progress |

---

## Headline Interpretation

| Total | What It Means | What To Say In Your Review |
|---|---|---|
| 48-60 | High-impact rollout | "GenAI judgment layer is delivering measurable value across all three roles. Recommend scaling to adjacent teams." |
| 36-47 | Solid adoption with focus areas | "Strong outcomes in [X]; [Y] needs attention. Recommend continuing with targeted improvements." |
| 24-35 | Early signal, more work needed | "Adoption proven, value emerging. Recommend extending the pilot for one more cycle and addressing identified gaps." |
| < 24 | Re-evaluate approach | "Limited measurable impact. Recommend interviewing engineers to understand barriers before continuing." |

---

## Three-Line Story For Your Slide

> **Drop your numbers into this skeleton:**
>
> *"In 4 weeks, our team caught **\[X\]** critical issues before merge, generated **\[Y\]** ADRs in design reviews, and resolved **\[Z\]** design deadlocks that would otherwise have cost days. Total scorecard: **\[N\]/60**."*

---

## Notable Stories

**Notable Win** *(one specific example, 2 sentences):*
_________________________________________________________________
_________________________________________________________________

**Notable Override** *(one specific case where the team disagreed with the LLM and why):*
_________________________________________________________________
_________________________________________________________________

**Next Quarter Focus** *(one prioritisation):*
_________________________________________________________________
_________________________________________________________________

---

## Calibration Health

The Override Rate row is the credibility row.

- 0% overrides → engineers have stopped reading the verdicts. Investigate.
- 80% overrides → the rubric is wrong for this team. Update `team_standards.md`.
- **10-25% overrides → calibrated and engaged. This is the signal leadership trusts.**

Report the override rate honestly. It makes every other number on this scorecard more believable.
