# Scorecard — Measuring GenAI Build Activity Impact

Use these templates to quantify what the judgment layer delivers in your day-to-day work — and present the results in your GenAI build activity review.

---

## 📋  How To Use

1. Copy `scorecard-template.md` to a new file: `scorecard-Q1-2025.md` (or whatever period you're tracking).
2. Fill in the **Baseline** column before you start using the judgment layer.
3. Use the layer for **4 weeks**.
4. Fill in the **Actual** column.
5. Score each row 1-5 using the rubric in the template.
6. Total your score and use the headline interpretation table to write your one-line review summary.

---

## 🎯  What "Good" Looks Like

| Total | Meaning |
|---|---|
| 48-60 | High-impact rollout — recommend scaling |
| 36-47 | Solid adoption with focus areas |
| 24-35 | Early signal, more work needed |
| < 24 | Re-evaluate approach |

The full white paper explains how to interpret each band and what to recommend in your review.

---

## 🔒  The One Honest Metric

The **Override Rate** row is the credibility row. A team with 0% overrides has stopped reading the verdicts. A team in the **10-25%** band is calibrated and engaged — that is the signal leadership trusts.

Report the override rate. It makes every other number on the scorecard more believable.
